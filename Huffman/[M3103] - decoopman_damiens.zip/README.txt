Pour utiliser le programme :
Saisir "./Compr_huffman" dans la console